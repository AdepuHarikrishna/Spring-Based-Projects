package com.validator;

import com.model.Employee;
import com.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
@Component
public class EmployeeValidator implements Validator {
@Autowired
EmployeeService employeeService;

    private static final String EMAIL_REFEX = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    @Override
    public boolean supports(Class<?> aClass) {
        return Employee.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
       Employee employee= (Employee) o;

       ValidationUtils .rejectIfEmptyOrWhitespace(errors,"userName","employee.userName.iempty");
        ValidationUtils .rejectIfEmptyOrWhitespace(errors,"password","employee.password");
        ValidationUtils .rejectIfEmptyOrWhitespace(errors,"firstName","employee.firstName");
        ValidationUtils .rejectIfEmptyOrWhitespace(errors,"lastName","employee.lastName");
        ValidationUtils .rejectIfEmptyOrWhitespace(errors,"emailId","employee.emailId");

        String userName = employee.getUserName();
         if(!userName.matches(employeeService.exitUserName(userName))){
               errors.rejectValue("userName", "invalid.userName","userName already exist!!!");
        }
       String firstName =employee.getFirstName();
         if(!isAlphaString(firstName)){
             errors.rejectValue("firstName" ,"invalid.firstName", "please enter only character format(String Values)");
         }
        String lastName =employee.getFirstName();
        if(!isAlphaString(lastName)){
            errors.rejectValue("lastName" ,"invalid.lastName", "please enter only String format");
        }
        //validate email
        if(employee.getEmailId()==null||!employee.getEmailId().matches(EMAIL_REFEX)){
            errors.rejectValue("emailId" , "Invalid.employee.Email","Invalid email format");
        }

    }
    private boolean isAlphaString(String value) {
        return value.matches("^[a-zA-Z]+$");
    }
}
