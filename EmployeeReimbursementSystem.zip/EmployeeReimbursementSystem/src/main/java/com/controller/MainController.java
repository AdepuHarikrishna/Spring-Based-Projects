package com.controller;

import com.model.Employee;
import com.service.EmployeeService;

import com.validator.EmployeeValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Controller

public class MainController {
    @Autowired
    EmployeeService employeeService;
   @Autowired
   EmployeeValidator employeeValidator;
    @Autowired
    PasswordEncoder passwordEncoder;

    @RequestMapping("/")
    public String index(){
        //System.out.println("hhkefh");
        return  "homePage";
    }
    @RequestMapping("/login")
    public String login(Employee employee){
        System.out.println(employee);

        return "Login";

    }
    @RequestMapping("/reg")
    public String reg(@ModelAttribute Employee employee){

        return "Register";
    }
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String register(@Valid @ModelAttribute Employee employee , BindingResult bindingResult) {
       employeeValidator.validate(employee, bindingResult);
        if(bindingResult.hasErrors()){
            System.out.println("entered");
            return "Register";
        }else {
           // System.out.println("data into the database");
            String encode = passwordEncoder.encode(employee.getPassword());
            employee.setPassword(encode);
            employeeService.createEmployee(employee);
            return "redirect:/";
        }

    }
    @RequestMapping("/managerPage")
    public  String adminHomepage(){
        //System.out.println("trrr");
        return "managerPage";
    }

    @RequestMapping("/employeepage")
    public String userPage() {

        return "employeePage";
    }
    @RequestMapping("/loginError")
    public String loginError(Model model){
        model.addAttribute("loginError", "Invalid Credentials");
        return "Login";
    }

    @RequestMapping("/logout")
    public String logout(){

        return "Logout";
    }

    @GetMapping("/accountBlock")
    public String accountBlock(Model model) {
        LocalDateTime timestamp = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedTimestamp = timestamp.format(formatter);
        model.addAttribute("timestamp", formattedTimestamp);

        return "accountBlock";
    }



    @RequestMapping ("/deniederror")

    public String deniederrorPage(){
        return "denied";
    }


}
