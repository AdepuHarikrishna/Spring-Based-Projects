package com.dao.Impl;

import com.dao.EmployeeDao;
import com.model.Employee;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao {

    JdbcTemplate jdbcTemplate;
    @Override
    public int createEmployee(Employee employee) {

        String query = "insert into employee_tab(userName, password, firstName, lastName, role, emailId) values (?, ?, ?, ?, ?, ?)";
        int result= jdbcTemplate.update(query , employee.getUserName(),employee.getPassword(),employee.getFirstName(),employee.getLastName(),employee.getRole(),employee.getEmailId());
        return result;
    }

    @Override
    public int updateEmployee(Employee employee) {
        String query = "update employee_tab set userName = ?, password = ?, firstName = ?, lastName = ?, emailId =? where empId = ?";
        int result = jdbcTemplate.update(query, employee.getUserName(),employee.getPassword(),employee.getFirstName(),employee.getLastName(),employee.getRole(),employee.getEmpId());
        return result;
    }

    @Override
    public int deleteEmployee(int empId) {
        String query = "delete from employee_tab where empId = ?";
        int result= jdbcTemplate.update(query,empId);
        return result;
    }

    @Override
    public Employee getEmployee(String userName, String password) {
        String query = "select * from employee_tab where userName = ? and password = ?";
        try {
            Employee employee = jdbcTemplate.queryForObject(query, new BeanPropertyRowMapper<>(Employee.class));
            return employee;
        }catch(EmptyResultDataAccessException ex) {
            return null;
        }

    }

    @Override
    public Employee getEmployee(int empId) {
        String query = "select * from employee_tab where empId=?";
        try {
            Employee employee = jdbcTemplate.queryForObject(query, new BeanPropertyRowMapper<>(Employee.class),empId);
            return employee;
        }catch(EmptyResultDataAccessException ex) {
            return null;
        }
    }

    @Override
    public void exitUserName(String userName) {
        String sql ="select userName from employee_tab";
         jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Employee.class));
    }

  /*  public boolean recordExist(int empId) {

        String sql = "SELECT COUNT(*) FROM employee_tab WHERE empId = ?";
        int count = jdbcTemplate.queryForObject(sql, Integer.class, empId);
        return count > 0;
    }*/

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
