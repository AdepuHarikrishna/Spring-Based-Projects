package com.dao.Impl;

import com.dao.EmployeeDao;
import com.dao.ReimbursementDao;
import com.model.Employee;
import com.model.Reimbursement;
import com.util.DateConversion;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.Date;
import java.util.List;

public class ReimbursementDaoImpl implements ReimbursementDao {

     JdbcTemplate jdbcTemplate;
    @Override
    public int insertReimbursement(Reimbursement reimbursement) {

      //    String emp="select empId from employee_tab where userName='"+employee.getUserName()+"'";
       //   reimbursement.setEmpId(Integer.parseInt(emp));
        String query = "insert into reimbursement_info (empId ,reason, amount, status, raisedOn,userName) values ( ?, ?, ?, ?,?,?)";

        int result = jdbcTemplate.update(query, reimbursement.getEmpId(), reimbursement.getReason(), reimbursement.getAmount(), "PENDING", DateConversion.convertDateFromUtilToSql(new Date()),reimbursement.getUserName());
        return result;
    }

    @Override
    public List<Reimbursement> getAllReimbursements(int empId) {


        String query = "select r.reimbursementId, r.empId, r.reason, r.amount, r.status,r.raisedOn from reimbursement_info r join employee_tab u on r.empId = u.empId and r.empId = ?";
        List<Reimbursement> reimbursements = jdbcTemplate.query(query, new BeanPropertyRowMapper<Reimbursement>(Reimbursement.class) , empId);
        return reimbursements;

    }

    @Override
    public List<Reimbursement> getAllReimbursements() {
        String query = "select reimbursementId,  reason, amount, status, raisedOn,u.userName,u.empId from reimbursement_info r  join employee_tab u  on r.empId = u.empId";
        List<Reimbursement> reimbursements = jdbcTemplate.query(query, new BeanPropertyRowMapper<Reimbursement>(Reimbursement.class));
        return reimbursements;
    }

    @Override
    public int updateReimbursement(Reimbursement reimbursement) {
        String query = "update reimbursement_info set status = ? where reimbursementId = ?";
        int result = jdbcTemplate.update(query, reimbursement.getStatus(),reimbursement.getReimbursementId());
        return result;
    }

    @Override
    public Reimbursement getId(int reimbursementId) {
        String sql= "select * from reimbursement_info where reimbursementId='"+reimbursementId+"' ";
        return jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper<>(Reimbursement.class));
    }

    @Override
    public void delete(int id) {
        String sql = "delete from reimbursement_info where reimbursementId='"+id+"'";

         jdbcTemplate.update(sql );
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}
