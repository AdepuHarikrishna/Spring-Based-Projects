package com.service;

import com.model.Employee;

public interface EmployeeService {
    /**
     * Creates a new employee record in the system.
     *
     * @param employee The Employee object containing information for the new employee.
     * @return String indicating the success (typically 1) or failure (typically 0) of the creation.
     */
    String createEmployee(Employee employee);

    /**
     * Updates an existing employee record in the system.
     *
     * @param employee The Employee object containing updated information.
     * @return String indicating the success (typically 1) or failure (typically 0) of the update.
     */
    String updateEmployee(Employee employee);

    /**
     * Deletes an employee record based on the provided employee ID.
     *
     * @param empId The unique identifier of the employee to be deleted.
     * @return String indicating the success (typically 1) or failure (typically 0) of the deletion.
     */
    String deleteEmployee(int empId);

    /**
     * Retrieves an employee record based on the provided username and password.
     *
     * @param userName The username associated with the employee.
     * @param password The password associated with the employee.
     * @return An Employee object representing the employee information if authentication is successful, or null otherwise.
     */
    Employee getEmployee(String userName, String password);
    Employee getEmployee(int empId);
/*    boolean  recordExist(int empId);*/
      String exitUserName(String userName);
}
