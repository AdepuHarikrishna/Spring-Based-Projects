package com.service.Impl;

import com.dao.ReimbursementDao;
import com.model.Employee;
import com.model.Reimbursement;
import com.service.ReimbursementService;

import java.util.List;

public class ReimbursementServiceImpl implements ReimbursementService {
    ReimbursementDao reimbursementDao;
    @Override
    public String insertReimbursement(Reimbursement reimbursement) {

        int result = reimbursementDao.insertReimbursement(reimbursement);
        if(result != 0) {
            return "Reimubursement applied successfully";
        }else {
            return "Reimbursement application failed";
        }

    }

    @Override
    public List<Reimbursement> getAllReimbursements(int empId) {
        List<Reimbursement> reimbursements = reimbursementDao.getAllReimbursements(empId);
        return reimbursements;
    }

    @Override
    public List<Reimbursement> getAllReimbursements() {
        List<Reimbursement> reimbursements = reimbursementDao.getAllReimbursements();
      //  Employee employee = new Employee();

        return reimbursements;
    }

    @Override
    public String updateReimbursement(Reimbursement reimbursement) {
        int result = reimbursementDao.updateReimbursement(reimbursement);
        if(result != 0) {
            return "success";
        }else {
            return "Failure";
        }
    }
    @Override
    public Reimbursement getId(int reimbursementId) {
     return reimbursementDao.getId(reimbursementId);
    }

    @Override
    public void delete(int id) {
    reimbursementDao.delete(id);
    }

    public ReimbursementDao getReimbursementDao() {
        return reimbursementDao;
    }

    public void setReimbursementDao(ReimbursementDao reimbursementDao) {
        this.reimbursementDao = reimbursementDao;
    }
}
