package com.controller;

import com.model.Employee;
import com.model.Reimbursement;
import com.service.ReimbursementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/reimbursement")
public class ReimbursementController {
    @Autowired
    ReimbursementService reimbursementService;
  /*  @Autowired
    ReimbursementValidator reimbursementValidator;*/
   /* @Autowired
    PasswordEncoder passwordEncoder;*/
         @RequestMapping("/home")
         public String home(){
             return "homeslides";
         }

          @RequestMapping("/applyReim")
             public  String applyReimbursement(@ModelAttribute("reimbursement") Reimbursement reimbursement){

              return "applyReimbursement";
          }

        @RequestMapping("/saveReim")
    public String saveReimbursement(@ModelAttribute("reimbursement")Reimbursement reimbursement , Model model){

              reimbursementService.insertReimbursement(reimbursement);
         //   System.out.println(reimbursementService.insertReimbursement(reimbursement));
            System.out.println("holle");
              model.addAttribute("hiii", "Reimbursement applied successfully");

              return  "applyReimbursement";
        }
        @RequestMapping("myReimbursement")
    public String myReimbursement(){
             return "myReimbursement";
        }
       @RequestMapping("/myReim")
    public String showMyReimbursement(@ModelAttribute("reimbursement")Reimbursement reimbursement , Employee employee, Model model){

      List<Reimbursement> reimbursement1= reimbursementService.getAllReimbursements();
           System.out.println(reimbursement1);
             model.addAttribute("reim" ,reimbursement1 );
             return "showReimbursements";
        }

        @RequestMapping("/viewReimbursement")
    public String viewReimbursement( Reimbursement reimbursement,Model model ){

           List<Reimbursement>  reimbursementList=reimbursementService.getAllReimbursements();
           model.addAttribute("reim",reimbursementList);
             return "viewReimbursement";
        }
        @RequestMapping("/resolveReimbursement")
    public String resolveReimbursement(@ModelAttribute ("reim") Reimbursement reimbursement){
            System.out.println("workng");
             return "reimbursementId";
        }
@RequestMapping("/viewId")
public String viewId(@RequestParam String reimbursementId ,@RequestParam String status ,Model model){
    System.out.println(reimbursementId);
       Reimbursement reimbursement1=    reimbursementService.getId(Integer.parseInt(reimbursementId));

       reimbursement1.setStatus(status);
       reimbursementService.updateReimbursement(reimbursement1);
    //System.out.println( reimbursementService.updateReimbursement(reimbursement1));
    System.out.println(reimbursement1);
    model.addAttribute("reim" ,reimbursement1);
       return "updatedStatus"   ;
}
/*@RequestMapping("/showStatus")
    public String showStatus(@RequestParam String showStatus , Model model){
              reimbursementService.updateReimbursement()
             return "reimbursementId";
}*/


    @RequestMapping("/delete/{id}")
    public String deleteReimbursement(@PathVariable int id){
     //   System.out.println("jj");
           reimbursementService.delete(id);
       //    System.out.println("delete");
        return "redirect:/reimbursement/viewReimbursement";
    }
}


