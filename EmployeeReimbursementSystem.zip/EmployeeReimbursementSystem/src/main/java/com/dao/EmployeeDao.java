package com.dao;


import com.model.Employee;

public interface EmployeeDao {
    /**
     * Creates a new employee record in the system.
     *
     * @param employee The Employee object containing information for the new employee.
     * @return An integer indicating the success (typically 1) or failure (typically 0) of the creation.
     */
    int createEmployee(Employee employee);

    /**
     * Updates an existing employee record in the system.
     *
     * @param employee The Employee object containing updated information.
     * @return An integer indicating the success (typically 1) or failure (typically 0) of the update.
     */
    int updateEmployee(Employee employee);

    /**
     * Deletes an employee record based on the provided employee ID.
     *
     * @param empId The unique identifier of the employee to be deleted.
     * @return An integer indicating the success (typically 1) or failure (typically 0) of the deletion.
     */
    int deleteEmployee(int empId);

    /**
     * Retrieves an employee record based on the provided username and password.
     *
     * @param userName The username associated with the employee.
     * @param password The password associated with the employee.
     * @return An Employee object representing the employee information if authentication is successful, or null otherwise.
     */
    Employee getEmployee(String userName, String password);
    Employee getEmployee(int empId);
 /* boolean  recordExist(int empId);*/
 void exitUserName(String userName);
 //int getId (int empId);
}
