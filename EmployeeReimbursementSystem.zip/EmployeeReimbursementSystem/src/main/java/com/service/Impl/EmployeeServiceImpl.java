package com.service.Impl;

import com.dao.EmployeeDao;
import com.model.Employee;
import com.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

    EmployeeDao employeeDao;
    @Override
    public String createEmployee(Employee employee) {
       int result = employeeDao.createEmployee(employee);
        if(result != 0) {
            return "Employee applied successfully";
        }else {
            return "Employee application failed";
        }

    }

    @Override
    public String updateEmployee(Employee employee) {
        int result= employeeDao.updateEmployee(employee);
        if(result != 0) {
            return "User updation success";
        }else {
            return "User updation failure";
        }
    }

    @Override
    public String deleteEmployee(int empId) {
        int result = employeeDao.deleteEmployee(empId);
        if(result != 0) {
            return "User deletion success";
        }else {
            return "User deletion failure";
        }
    }

    @Override
    public Employee getEmployee(String userName, String password) {

        return employeeDao.getEmployee(userName, password);
    }

    @Override
    public Employee getEmployee(int empId) {
        return employeeDao.getEmployee(empId);
    }

    @Override
    public String exitUserName(String userName) {
        employeeDao.exitUserName(userName);
        return userName;
    }


    public EmployeeDao getEmployeeDao() {
        return employeeDao;
    }

    public void setEmployeeDao(EmployeeDao employeeDao) {
        this.employeeDao = employeeDao;
    }
}
