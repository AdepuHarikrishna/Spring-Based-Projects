package com.service;

import com.model.Employee;
import com.model.Reimbursement;

import java.util.List;

public interface ReimbursementService {
    /**
     * Inserts a new reimbursement record into the system.
     *
     * @param reimbursement The Reimbursement object containing information for the new reimbursement.
     * @return  String indicating the success (typically 1) or failure (typically 0) of the insertion.
     */
    String insertReimbursement(Reimbursement reimbursement );

    /**
     * Retrieves all reimbursements associated with a specific employee.
     *
     * @param empId The unique identifier of the employee.
     * @return A list of Reimbursement objects representing all reimbursements for the specified employee.
     */
    List<Reimbursement> getAllReimbursements(int empId);

    /**
     * Retrieves all reimbursements in the system.
     *
     * @return A list of Reimbursement objects representing all reimbursements in the system.
     */
    List<Reimbursement> getAllReimbursements();

    /**
     * Updates an existing reimbursement record in the system.
     *
     * @param reimbursement The Reimbursement object containing updated information.
     * @return String indicating the success (typically 1) or failure (typically 0) of the update.
     */
    String updateReimbursement(Reimbursement reimbursement);
    Reimbursement getId(int reimbursementId);
    void delete (int id);
}
