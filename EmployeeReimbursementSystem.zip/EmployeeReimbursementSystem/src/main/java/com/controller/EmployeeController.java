package com.controller;

import com.model.Employee;
import com.service.EmployeeService;
import com.validator.EmployeeValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;
    /* @RequestMapping("/viewProfile")
     public String getempIds( Model model ,@RequestParam int empId){
         System.out.println("hh");
         model.addAttribute("e",employeeService.getId(empId));
         System.out.println(empId);
         return "getIds";
     }*/

    @RequestMapping("/viewProfile/{empId}")
    public  String showForm(@PathVariable int empId , Model model){

     Employee employee1=    employeeService.getEmployee(empId);
       System.out.println(employee1);
        model.addAttribute("emp" , employee1);
        return "showpage";
    }










}
